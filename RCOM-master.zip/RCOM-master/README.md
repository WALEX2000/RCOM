RCOM ok? 💩💩💩🙉

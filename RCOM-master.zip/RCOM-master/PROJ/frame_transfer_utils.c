#include "frame_transfer_utils.h"

MessagePacket read_frame(int fd) {

}